<label class="label-header">Quiz 1</label>
<div class="border-box quiz correct">
    <label>1. What is asd asdf asd f?</label>
    <div class="choice">
        <input id="choice0" type="radio" name="0" value="asdf">
        <label for="choice0">Asdf</label>
    </div>
    <div class="choice">
        <input id="choice1" type="radio" name="0" value="asdf">
        <label for="choice1">Asdf<div class="mark">&#x2718</div></label>
    </div>
    <div class="choice">
        <input id="choice2" type="radio" name="0" value="asdf">
        <label for="choice2">Asdf</label>
    </div>
    <div class="choice">
        <input id="choice3" type="radio" name="0" value="asdf">
        <label for="choice3">Asdf</label>
    </div>
</div>
<div class="border-box quiz">
    <label>1. What is asd asdf asd f?</label>
    <div class="choice">
        <input id="choice0" type="radio" name="1" value="asdf">
        <label for="choice0">Asdf</label>
    </div>
    <div class="choice">
        <input id="choice5" type="radio" name="1" value="asdf">
        <label for="choice5">Asdf</label>
    </div>
    <div class="choice">
        <input id="choice6" type="radio" name="1" value="asdf">
        <label for="choice6">Asdf</label>
    </div>
    <div class="choice">
        <input id="choice7" type="radio" name="1" value="asdf">
        <label for="choice7">Asdf</label>
    </div>
</div>

<div class="border-box">
    You have gotten 100%
</div>
